# Welcome to Journalbeat 6.7.1

Journalbeat ships systemd journal entries to Elasticsearch or Logstash.

## Getting Started

To get started with Journalbeat, you need to set up Elasticsearch on
your localhost first. After that, start Journalbeat with:

     ./journalbeat -c journalbeat.yml -e

This will start Journalbeat and send the data to your Elasticsearch
instance. To load the dashboards for Journalbeat into Kibana, run:

    ./journalbeat setup -e

For further steps visit the
[Getting started](https://www.elastic.co/guide/en/beats/journalbeat/6.7/journalbeat-getting-started.html) guide.

## Documentation

Visit [Elastic.co Docs](https://www.elastic.co/guide/en/beats/journalbeat/6.7/index.html)
for the full Journalbeat documentation.

## Release notes

https://www.elastic.co/guide/en/beats/libbeat/6.7/release-notes-6.7.1.html
